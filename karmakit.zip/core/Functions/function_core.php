<?php
/**
 * @project     : KarmaKit
 * @version     : 1.0.0
 * @author      : Karma Team
 * @date        : 2022-10-17
 * @website     : https://karmatechhub.com
 */
defined('ABSPATH') or exit();


if(!function_exists('karma_kit')){
    /**
     * @return \Karma\Kit\Loader
     */
    function karma_kit(){
        global $karma_kit;
        return $karma_kit;
    }
}


if(!function_exists('kk_get_header_id')){

    function kk_get_header_id(){

        // make query get current footer id

        // test
        return 51;
    }
}

if(!function_exists('kk_get_footer_id')){

    function kk_get_footer_id(){

        // make query get current footer id

        // test
        return 51;
    }
}
