<?php
namespace Karma\Kit\PostType;

use WpTool\Helper\PostType;

/**
 * @project     : KarmaKit
 * @version     : 1.0.0
 * @author      : Karma Team
 * @date        : 2022-10-18
 * @website     : https://karmatechhub.com
 */
defined('ABSPATH') or exit();

class Template extends PostType
{

    /**
     * post type name
     *
     * @var string
     */
    protected $type = 'karma-kit-template';

    protected $args = [
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => false,
        'show_in_nav_menus'   => false,
        'exclude_from_search' => true,
        'capability_type'     => 'post',
        'hierarchical'        => false,
        'menu_icon'           => 'dashicons-editor-kitchensink',
        'supports'            => [ 'title', 'thumbnail', 'elementor' ],
    ];

    protected $labels = [
        'name'                  => 'Templates',
        'singular_name'         => 'Template',
        'menu_name'             => 'Templates',
        'name_admin_bar'        => 'Template',
        'add_new'               => 'Add New',
        'add_new_item'          => 'Add New template',
        'new_item'              => 'New template',
        'edit_item'             => 'Edit template',
        'view_item'             => 'View template',
        'all_items'             => 'All templates',
        'search_items'          => 'Search templates',
        'parent_item_colon'     => 'Parent templates:',
        'not_found'             => 'No templates found.',
        'not_found_in_trash'    => 'No templates found in Trash.',
    ];

    function init()
    {
        add_filter( 'single_template', [ $this, 'load_canvas_template' ] );
        add_action( 'add_meta_boxes', [ $this, 'register_metabox' ] );
        add_action( 'save_post', [ $this, 'save_meta' ] );
        add_action( 'template_redirect', [ $this, 'block_template_frontend' ] );

    }

    /**
     * load template
     *
     * @return void
     */
    public function load_canvas_template($single_template)
    {
        global $post;

        if ( $this->type == $post->post_type && defined('ELEMENTOR_PATH') && ELEMENTOR_PATH ) {
            $elementor_2_0_canvas = ELEMENTOR_PATH . '/modules/page-templates/templates/canvas.php';

            if ( file_exists( $elementor_2_0_canvas ) ) {
                return $elementor_2_0_canvas;
            } else {
                return ELEMENTOR_PATH . '/includes/page-templates/canvas.php';
            }
        }

        return $single_template;
    }

    /**
     * register metabox
     *
     * @return void
     */
    public function register_metabox()
    {
        add_meta_box(
            'karma-kit-meta-box',
            __( 'Karma Template Options', 'karmakit' ),
            [
                $this,
                'metabox_render',
            ],
            [ $this->type ],
            'normal',
            'high'
        );

    }


    /**
     *
     *
     * @return void
     */
    public function metabox_render($post)
    {
        echo karma_kit()->view('template-metabox', [
            'post' => $post,
            'template' => $this
        ]);
    }


    /**
     * save meta
     *
     * @return void
     */
    public function save_meta($post_id)
    {
        // Bail if we're doing an auto save.
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        // if our nonce isn't there, or we can't verify it, bail.
        if ( ! isset( $_POST['ekm_meta_nounce'] ) || ! wp_verify_nonce( $_POST['ekm_meta_nounce'], 'ekm_meta_nounce' ) ) {
            return;
        }

        // if our current user can't edit this post, bail.
        if ( ! current_user_can( 'edit_posts' ) ) {
            return;
        }


        if ( isset( $_POST['ekm_template_type'] ) ) {
            update_post_meta( $post_id, 'ekm_template_type', esc_attr( $_POST['ekm_template_type'] ) );
        }

    }

    /**
     * redirect post
     *
     * @return void
     */
    public function block_template_frontend()
    {
        if ( is_singular( $this->type ) && ! current_user_can( 'edit_posts' ) ) {
            wp_redirect( site_url(), 301 );
            die;
        }
    }


}
