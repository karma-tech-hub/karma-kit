<?php
namespace Karma\Widgets\Footer;
/**
 * @project     : KarmaKit
 * @version     : 1.0.0
 * @author      : Karma Team
 * @date        : 2022-10-16
 * @website     : https://karmatechhub.com
 */
defined('ABSPATH') or exit();

class Footer extends \Elementor\Widget_Base
{

    /**
     * set widget name
     *
     * @return string|null
     */
    public function get_name()
    {
        return __('Footer', 'karmakit');
    }


    /**
     * set widget title
     *
     * @return string|null
     */
    public function get_title()
    {
        return __('Footer', 'karmakit');
    }


    /**
     * set widget category
     *
     * @return array
     */
    public function get_categories()
    {
        return [KARMA_KIT_GROUP];
    }


    /**
     * register controls
     *
     * @return void
     */
    protected function register_controls()
    {
        $this->start_controls_section(
            'layout',
            [
                'label' => esc_html__( 'Layout', 'karmakit' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT
            ]
        );



        $this->end_controls_section();
    }


    /**
     * render widget
     *
     * @return void
     */
    protected function render()
    {

    }


}
