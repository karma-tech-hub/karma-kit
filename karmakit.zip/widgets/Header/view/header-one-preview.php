<?php
/**
 * @project     : KarmaKit
 * @version     : 1.0.0
 * @author      : Karma Team
 * @date        : 2022-10-17
 * @website     : https://karmatechhub.com
 */
defined('ABSPATH') or exit();
?>
<header class=" header-style-{{{ settings.style }}}">

</header>
