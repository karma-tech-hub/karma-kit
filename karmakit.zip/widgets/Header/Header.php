<?php

namespace Karma\Widgets\Header;

/**
 * @project     : KarmaKit
 * @version     : 1.0.0
 * @author      : Karma Team
 * @date        : 2022-10-16
 * @website     : https://karmatechhub.com
 */
defined('ABSPATH') or exit();

class Header extends \Elementor\Widget_Base
{

    /**
     * set widget name
     *
     * @return string|null
     */
    public function get_name()
    {
        return __('Header', 'karmakit');
    }


    /**
     * set widget title
     *
     * @return string|null
     */
    public function get_title()
    {
        return __('Header', 'karmakit');
    }


    /**
     * set widget category
     *
     * @return array
     */
    public function get_categories()
    {
        return [ KARMA_KIT_GROUP ];
    }


    /**
     * register controls
     *
     * @return void
     */
    protected function register_controls()
    {
        $this->start_controls_section(
            'layouts',
            [
                'label' => esc_html__( 'Layout', 'karmakit' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT
            ]
        );


        $this->add_control(
            'layout',
            [
                'type' => \Elementor\Controls_Manager::SELECT,
                'label' => esc_html__( 'Layout', 'karmakit' ),
                'options' => [
                    'one' => 'Layout One',
                ],
                'default' => 'one'
            ]
        );


        $this->add_control(
            'style',
            [
                'type' => \Elementor\Controls_Manager::SELECT,
                'label' => esc_html__( 'Style', 'karmakit' ),
                'options' => [
                    'style-one' => 'Style One',
                    'style-two' => 'Style Two',
                    'style-three' => 'Style Three',
                ],
                'default' => 'style-one'
            ]
        );

        $this->end_controls_section();
    }

    /**
     * get layout
     *
     * @return mixed
     */
    public function get_layout()
    {
        $layout = $this->get_settings_for_display('layout');
        return $layout ? '-' . $layout : false;
    }


    /**
     * render widget
     *
     * @return void
     */
    protected function render()
    {
        $layout = $this->get_layout();
        karma_kit()->view_widget("Header/view/header{$layout}", [
            'widget' => $this
        ]);
    }


}
