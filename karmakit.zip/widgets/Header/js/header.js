/**
 * @project        Karma Kit
 * @author         Karma Team
 * @website        https://karamtechhub.com
 * @version       1.0.0
 *
 */

/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!**************************************!*\
  !*** ./widgets/header/src/header.js ***!
  \**************************************/

/******/ })()
;